# Assignment4.3
Windows form assignments

1. Play with controls! Use different controls on windows forms and change their properties.

2. Create a structure : Student with fields like studid, firstname, lastname, address,monthofadmission,grade .: A, B,C

Create a list of students  and perform following operations in windows application:

* add new records,
* delete record and
* display them in grid.
* Monthofadmission should be enum.
